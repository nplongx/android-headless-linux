#!/system/bin/sh
rm -f /data/local/tmp/linuxdeploy-headless-boot.log
