#!/system/bin/sh
LOG=/data/local/tmp/linuxdeploy-headless-boot.log
START=/data/local/tmp/linuxdeploy-headless-start-fixed.sh
{
  echo "[$(date '+%F %T')] boot trigger started"
  i=0
  while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$i" -lt 60 ]; do
    sleep 2
    i=$((i+1))
  done
  if [ "$(getprop sys.boot_completed)" != "1" ]; then
    echo "[$(date '+%F %T')] boot_completed timeout; exit"
    exit 0
  fi
  echo "[$(date '+%F %T')] boot_completed=1"
  if [ ! -x "$START" ]; then
    echo "[$(date '+%F %T')] start script missing/not executable; exit"
    exit 0
  fi
  if grep -q ' /data/local/mnt ' /proc/mounts 2>/dev/null; then
    echo "[$(date '+%F %T')] rootfs already mounted; exit"
    exit 0
  fi
  "$START" >>"$LOG" 2>&1
  rc=$?
  echo "[$(date '+%F %T')] start rc=$rc"
} >>"$LOG" 2>&1
exit 0
