#!/system/bin/sh
rm -f /data/local/tmp/m12-safe-ram.log /data/adb/m12-safe-ram.disabled
