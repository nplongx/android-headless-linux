#!/system/bin/sh
# Android Safe RAM: no runtime tuning, no process/package killing, no watchdog.
# LMKD tuning is supplied exclusively through system.prop at boot.
exit 0
