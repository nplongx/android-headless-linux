#!/system/bin/sh
rm -f /data/local/tmp/android-safe-ram.log /data/adb/android-safe-ram.disabled
